package kr.ac.skuniv.todo.service;

import java.util.List;

import kr.ac.skuniv.todo.dao.TodoDAO;
import kr.ac.skuniv.todo.dto.Todo;

public class TodoService {
	TodoDAO dao = new TodoDAO();

	public void addTodo(String todo,String id) {
		 dao.addTodo(todo,id);
		 System.out.println("AddtodoService");
	}
	public void addTestTodo(String todo) {
		 dao.addTestTodo(todo);
	}
	public List<Todo> getTodoList(){
		return dao.getTodoList();
	}

	public void deleteTodo(int listNum) {
		dao.deleteTodo(listNum);
	}
	
	public Todo getTodo(String id) {
		return dao.getTodo(id);
	}
	
	public void updateTodoDone(Todo todo) {
		dao.updateTodo(todo);
	}
	public List<Todo> getTodoList(String id){//해당id의 list만 받는다.
		return dao.getTodoList(id);
	}
}
