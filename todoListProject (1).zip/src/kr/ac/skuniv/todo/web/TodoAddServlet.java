package kr.ac.skuniv.todo.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.ac.skuniv.todo.dto.Todo;
import kr.ac.skuniv.todo.service.TodoService;


@WebServlet("/todoAdd")
public class TodoAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		String id1=(String) session.getAttribute("login");
		request.setCharacterEncoding("utf-8");
		
		TodoService todoService = new TodoService();
		todoService.addTodo(request.getParameter("todo"), id1);
		System.out.println("todoAddServlet");
		

		response.sendRedirect("todoListOneId");
	}


}
