package kr.ac.skuniv.todo.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.ac.skuniv.todo.dto.Todo;
import kr.ac.skuniv.todo.service.TodoService;

@WebServlet("/todoUpdate")
public class TodoUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		TodoService todoService = new TodoService();
		request.setCharacterEncoding("utf-8");
		Todo todo = new Todo();

		todo.setListNum(Integer.parseInt(request.getParameter("listNum")));
		todo.setId(request.getParameter("id"));

		Boolean status = Boolean.parseBoolean(request.getParameter("done"));

		if (status == false) {
			todo.setDone(true);
		} else if (status == true) {
			todo.setDone(false);
		}

		todo.setTodo(request.getParameter("todo"));
		todoService.updateTodoDone(todo);

		response.sendRedirect("todoListOneId");

	}

}
