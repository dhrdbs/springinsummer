package kr.ac.skuniv.todo.dto;

public class Todo {
	
	private int listNum;
	private String id;
	private boolean done;
	private String todo;

	
	
	public int getListNum() {
		return listNum;
	}
	public void setListNum(int listNum) {
		this.listNum = listNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isDone() {
		return done;
	}
	public void setDone(boolean done) {
		this.done = done;
	}
	public String getTodo() {
		return todo;
	}
	public void setTodo(String todo) {
		this.todo = todo;
	}
	
	public String toString() {
		return "Todo [id=" + id + ", done=" + done + ", todo=" + todo + "]";
	}

}
