package kr.ac.skuniv.todo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.ac.skuniv.common.DBUtil;
import kr.ac.skuniv.todo.dto.Todo;

public class TodoDAO {

	public int addTodo(String todo, String id) {// 할일만 추가
		int resultCount = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		// String id1=(String) session.getAttribute("login");
		try {
			conn = DBUtil.getConnection();
			String sql = "insert into todo(todo,id) values(?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, todo);
			ps.setString(2, id);
			resultCount = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps);
		}
		return resultCount;
	}

	public int addTestTodo(String todo) {// 할일만 추가
		int resultCount = 0;
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "insert into todo(todo,id) values(?,11)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, todo);
			// ps.setString(2, todo.getId());
			ps.executeUpdate();
			resultCount = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps);
		}
		return resultCount;
	}

	public int updateTodo(Todo todo) {
		int resultCount = 0;

		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;

		try {
			conn = DBUtil.getConnection();
			sql = "update todo set done=? where ListNum=?";
			ps = conn.prepareStatement(sql);
			ps.setBoolean(1, todo.isDone());
			ps.setInt(2, todo.getListNum());

			resultCount = ps.executeUpdate();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps);
		}
		return resultCount;
	}

	public int deleteTodo(int listNum) {
		int resultCount = 0;
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "delete from todo where listNum=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, listNum);

			resultCount = ps.executeUpdate();

		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps);
		}

		return resultCount;
	}

	public Todo getTodo(String id) {
		Todo todo = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select id, done, todo from todo,listNum where id=? ";
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();

			if (rs.next()) {
				todo = new Todo();
				todo.setId(rs.getString(1));
				todo.setDone(rs.getBoolean(2));
				todo.setTodo(rs.getString(3));
				todo.setListNum(rs.getInt(4));
			}

		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps);
		}
		return todo;

	}

	public List<Todo> getTodoList() {
		List<Todo> todoList = new ArrayList<>();

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select id, done, todo,listNum from todo";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				Todo todo = new Todo();
				todo.setId(rs.getString(1));
				todo.setDone(rs.getBoolean(2));
				todo.setTodo(rs.getString(3));
				todo.setListNum(rs.getInt(4));
				todoList.add(todo);
			}

		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps, rs);
		}

		return todoList;

	}

	public List<Todo> getTodoList(String id) {// 해당 아이디의 todo리스트만 가져온다.
		List<Todo> todoList = new ArrayList<>();

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select id, done, todo,listNum from todo where id=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();

			while (rs.next()) {
				Todo todo = new Todo();
				todo.setId(rs.getString(1));
				todo.setDone(rs.getBoolean(2));
				todo.setTodo(rs.getString(3));
				todo.setListNum(rs.getInt(4));

				todoList.add(todo);
			}

		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, ps, rs);
		}

		return todoList;

	}

}
