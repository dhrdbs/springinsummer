package kr.ac.skuniv.member.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.ac.skuniv.member.service.MemberService;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		MemberService service = new MemberService();
		boolean loginFlag = service.login(id, password);
		HttpSession session = request.getSession();

		if(loginFlag) {
			//아이디 패스워드가 동일한 경우 -> 상태정보 유지
			//쿠키를 이용한 상태정보 유지
/*			Cookie cookie = new Cookie("login", id);
			cookie.setPath("/");
			cookie.setMaxAge(-1);
			
			response.addCookie(cookie);*/
			
			//세션을 이용한 상태정보 유지
	         session.setAttribute("login", id);
	         
	        
	        
			
			//로그인 성공시 도착하는 페이지
			response.sendRedirect("todoListOneId");
						
		}else {
			//아이디 패스워드가 잘못된 경우
			response.sendRedirect("loginForm.jsp");
			
		}
		
	}

}



